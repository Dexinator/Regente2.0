--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE regente;
--
-- Name: regente; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE regente WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE regente OWNER TO root;

\connect regente

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: detalles_orden; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.detalles_orden (
    id integer NOT NULL,
    orden_id integer NOT NULL,
    producto_id integer NOT NULL,
    cantidad integer DEFAULT 1,
    precio_unitario numeric(10,2) NOT NULL,
    empleado_id integer NOT NULL
);


ALTER TABLE public.detalles_orden OWNER TO root;

--
-- Name: detalles_orden_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.detalles_orden_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.detalles_orden_id_seq OWNER TO root;

--
-- Name: detalles_orden_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.detalles_orden_id_seq OWNED BY public.detalles_orden.id;


--
-- Name: empleados; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.empleados (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    usuario character varying(50) NOT NULL,
    password text NOT NULL,
    rol text NOT NULL,
    fecha_ingreso date DEFAULT CURRENT_DATE,
    activo boolean DEFAULT true,
    CONSTRAINT empleados_rol_check CHECK ((rol = ANY (ARRAY['admin'::text, 'mesero'::text, 'cocinero'::text, 'financiero'::text])))
);


ALTER TABLE public.empleados OWNER TO root;

--
-- Name: empleados_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.empleados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.empleados_id_seq OWNER TO root;

--
-- Name: empleados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.empleados_id_seq OWNED BY public.empleados.id;


--
-- Name: grados; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.grados (
    id integer NOT NULL,
    nombre text NOT NULL,
    descuento numeric(5,2) NOT NULL
);


ALTER TABLE public.grados OWNER TO root;

--
-- Name: grados_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.grados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grados_id_seq OWNER TO root;

--
-- Name: grados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.grados_id_seq OWNED BY public.grados.id;


--
-- Name: ordenes; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.ordenes (
    orden_id integer NOT NULL,
    preso_id integer,
    nombre_cliente character varying(255),
    total numeric(10,2) NOT NULL,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    estado text DEFAULT 'abierta'::text,
    empleado_id integer NOT NULL,
    total_bruto numeric(10,2),
    CONSTRAINT ordenes_estado_check CHECK ((estado = ANY (ARRAY['abierta'::text, 'cerrada'::text])))
);


ALTER TABLE public.ordenes OWNER TO root;

--
-- Name: ordenes_orden_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.ordenes_orden_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ordenes_orden_id_seq OWNER TO root;

--
-- Name: ordenes_orden_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.ordenes_orden_id_seq OWNED BY public.ordenes.orden_id;


--
-- Name: pagos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.pagos (
    id integer NOT NULL,
    orden_id integer,
    metodo text NOT NULL,
    monto numeric(10,2) NOT NULL,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    empleado_id integer,
    CONSTRAINT pagos_metodo_check CHECK ((metodo = ANY (ARRAY['efectivo'::text, 'tarjeta'::text, 'transferencia'::text, 'otro'::text])))
);


ALTER TABLE public.pagos OWNER TO root;

--
-- Name: pagos_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.pagos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pagos_id_seq OWNER TO root;

--
-- Name: pagos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.pagos_id_seq OWNED BY public.pagos.id;


--
-- Name: preso_grado; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.preso_grado (
    id integer NOT NULL,
    preso_id integer,
    grado_id integer,
    fecha_otorgado date DEFAULT CURRENT_DATE
);


ALTER TABLE public.preso_grado OWNER TO root;

--
-- Name: preso_grado_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.preso_grado_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.preso_grado_id_seq OWNER TO root;

--
-- Name: preso_grado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.preso_grado_id_seq OWNED BY public.preso_grado.id;


--
-- Name: presos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.presos (
    id integer NOT NULL,
    reg_name text NOT NULL,
    res_tel text NOT NULL,
    igname text,
    bday text NOT NULL,
    mkt boolean NOT NULL,
    cellmate integer NOT NULL,
    referidos integer DEFAULT 0,
    fecha_registro date DEFAULT CURRENT_DATE
);


ALTER TABLE public.presos OWNER TO root;

--
-- Name: presos_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.presos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.presos_id_seq OWNER TO root;

--
-- Name: presos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.presos_id_seq OWNED BY public.presos.id;


--
-- Name: productos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.productos (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    precio numeric(10,2) NOT NULL,
    categoria character varying(50),
    costo numeric(10,2)
);


ALTER TABLE public.productos OWNER TO root;

--
-- Name: productos_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.productos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.productos_id_seq OWNER TO root;

--
-- Name: productos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.productos_id_seq OWNED BY public.productos.id;


--
-- Name: detalles_orden id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.detalles_orden ALTER COLUMN id SET DEFAULT nextval('public.detalles_orden_id_seq'::regclass);


--
-- Name: empleados id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.empleados ALTER COLUMN id SET DEFAULT nextval('public.empleados_id_seq'::regclass);


--
-- Name: grados id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.grados ALTER COLUMN id SET DEFAULT nextval('public.grados_id_seq'::regclass);


--
-- Name: ordenes orden_id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ordenes ALTER COLUMN orden_id SET DEFAULT nextval('public.ordenes_orden_id_seq'::regclass);


--
-- Name: pagos id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.pagos ALTER COLUMN id SET DEFAULT nextval('public.pagos_id_seq'::regclass);


--
-- Name: preso_grado id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.preso_grado ALTER COLUMN id SET DEFAULT nextval('public.preso_grado_id_seq'::regclass);


--
-- Name: presos id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.presos ALTER COLUMN id SET DEFAULT nextval('public.presos_id_seq'::regclass);


--
-- Name: productos id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.productos ALTER COLUMN id SET DEFAULT nextval('public.productos_id_seq'::regclass);


--
-- Data for Name: detalles_orden; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.detalles_orden (id, orden_id, producto_id, cantidad, precio_unitario, empleado_id) FROM stdin;
\.
COPY public.detalles_orden (id, orden_id, producto_id, cantidad, precio_unitario, empleado_id) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: empleados; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.empleados (id, nombre, usuario, password, rol, fecha_ingreso, activo) FROM stdin;
\.
COPY public.empleados (id, nombre, usuario, password, rol, fecha_ingreso, activo) FROM '$$PATH$$/3441.dat';

--
-- Data for Name: grados; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.grados (id, nombre, descuento) FROM stdin;
\.
COPY public.grados (id, nombre, descuento) FROM '$$PATH$$/3450.dat';

--
-- Data for Name: ordenes; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.ordenes (orden_id, preso_id, nombre_cliente, total, fecha, estado, empleado_id, total_bruto) FROM stdin;
\.
COPY public.ordenes (orden_id, preso_id, nombre_cliente, total, fecha, estado, empleado_id, total_bruto) FROM '$$PATH$$/3443.dat';

--
-- Data for Name: pagos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.pagos (id, orden_id, metodo, monto, fecha, empleado_id) FROM stdin;
\.
COPY public.pagos (id, orden_id, metodo, monto, fecha, empleado_id) FROM '$$PATH$$/3454.dat';

--
-- Data for Name: preso_grado; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.preso_grado (id, preso_id, grado_id, fecha_otorgado) FROM stdin;
\.
COPY public.preso_grado (id, preso_id, grado_id, fecha_otorgado) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: presos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.presos (id, reg_name, res_tel, igname, bday, mkt, cellmate, referidos, fecha_registro) FROM stdin;
\.
COPY public.presos (id, reg_name, res_tel, igname, bday, mkt, cellmate, referidos, fecha_registro) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: productos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.productos (id, nombre, precio, categoria, costo) FROM stdin;
\.
COPY public.productos (id, nombre, precio, categoria, costo) FROM '$$PATH$$/3447.dat';

--
-- Name: detalles_orden_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.detalles_orden_id_seq', 42, true);


--
-- Name: empleados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.empleados_id_seq', 3, true);


--
-- Name: grados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.grados_id_seq', 1, true);


--
-- Name: ordenes_orden_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.ordenes_orden_id_seq', 42, true);


--
-- Name: pagos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.pagos_id_seq', 1, false);


--
-- Name: preso_grado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.preso_grado_id_seq', 1, true);


--
-- Name: presos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.presos_id_seq', 1, false);


--
-- Name: productos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.productos_id_seq', 1, false);


--
-- Name: detalles_orden detalles_orden_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.detalles_orden
    ADD CONSTRAINT detalles_orden_pkey PRIMARY KEY (id);


--
-- Name: empleados empleados_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.empleados
    ADD CONSTRAINT empleados_pkey PRIMARY KEY (id);


--
-- Name: empleados empleados_usuario_key; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.empleados
    ADD CONSTRAINT empleados_usuario_key UNIQUE (usuario);


--
-- Name: grados grados_nombre_key; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.grados
    ADD CONSTRAINT grados_nombre_key UNIQUE (nombre);


--
-- Name: grados grados_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.grados
    ADD CONSTRAINT grados_pkey PRIMARY KEY (id);


--
-- Name: ordenes ordenes_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_pkey PRIMARY KEY (orden_id);


--
-- Name: pagos pagos_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_pkey PRIMARY KEY (id);


--
-- Name: preso_grado preso_grado_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.preso_grado
    ADD CONSTRAINT preso_grado_pkey PRIMARY KEY (id);


--
-- Name: presos presos_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.presos
    ADD CONSTRAINT presos_pkey PRIMARY KEY (id);


--
-- Name: productos productos_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.productos
    ADD CONSTRAINT productos_pkey PRIMARY KEY (id);


--
-- Name: detalles_orden detalles_orden_empleado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.detalles_orden
    ADD CONSTRAINT detalles_orden_empleado_id_fkey FOREIGN KEY (empleado_id) REFERENCES public.empleados(id) ON DELETE CASCADE;


--
-- Name: detalles_orden detalles_orden_orden_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.detalles_orden
    ADD CONSTRAINT detalles_orden_orden_id_fkey FOREIGN KEY (orden_id) REFERENCES public.ordenes(orden_id) ON DELETE CASCADE;


--
-- Name: detalles_orden detalles_orden_producto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.detalles_orden
    ADD CONSTRAINT detalles_orden_producto_id_fkey FOREIGN KEY (producto_id) REFERENCES public.productos(id) ON DELETE CASCADE;


--
-- Name: ordenes ordenes_empleado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_empleado_id_fkey FOREIGN KEY (empleado_id) REFERENCES public.empleados(id) ON DELETE CASCADE;


--
-- Name: ordenes ordenes_preso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.ordenes
    ADD CONSTRAINT ordenes_preso_id_fkey FOREIGN KEY (preso_id) REFERENCES public.presos(id) ON DELETE SET NULL;


--
-- Name: pagos pagos_empleado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_empleado_id_fkey FOREIGN KEY (empleado_id) REFERENCES public.empleados(id);


--
-- Name: pagos pagos_orden_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.pagos
    ADD CONSTRAINT pagos_orden_id_fkey FOREIGN KEY (orden_id) REFERENCES public.ordenes(orden_id) ON DELETE CASCADE;


--
-- Name: preso_grado preso_grado_grado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.preso_grado
    ADD CONSTRAINT preso_grado_grado_id_fkey FOREIGN KEY (grado_id) REFERENCES public.grados(id) ON DELETE CASCADE;


--
-- Name: preso_grado preso_grado_preso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.preso_grado
    ADD CONSTRAINT preso_grado_preso_id_fkey FOREIGN KEY (preso_id) REFERENCES public.presos(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

